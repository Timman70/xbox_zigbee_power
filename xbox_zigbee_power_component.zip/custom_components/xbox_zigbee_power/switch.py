import logging
import time
from homeassistant.components.switch import SwitchEntity
from homeassistant.const import STATE_ON
from . import DOMAIN

_LOGGER = logging.getLogger(__name__)
XBOX_PING_SENSOR = "binary_sensor.xbox_ping"
COMMAND_CODE = (
    "BYMjqhE7AuATAQOrBjsC4AMBQA9AA0ABQAfgCwNAAUAX4A8BwBtAB0ADD3KsgyPHCDsC//+DI8cIOwI="
)

async def async_setup_entry(hass, config_entry, async_add_entities):
    ieee = config_entry.data["ieee"]
    async_add_entities([XboxPowerSwitch(hass, ieee)])

class XboxPowerSwitch(SwitchEntity):
    def __init__(self, hass, ieee):
        self.hass = hass
        self._ieee = ieee
        self._attr_name = "Xbox Power"
        self._attr_unique_id = f"xbox_power_{ieee.replace(':', '')}"
        self._attr_icon = "mdi:microsoft-xbox"

    async def async_turn_on(self, **kwargs):
        await self._send_command()
        await self._refresh()

    async def async_turn_off(self, **kwargs):
        await self._send_command()
        await self._refresh()

    async def _send_command(self):
        await self.hass.services.async_call("zha", "issue_zigbee_cluster_command", {
            "ieee": self._ieee,
            "endpoint_id": 1,
            "cluster_id": 57348,
            "command": 2,
            "command_type": "server",
            "cluster_type": "in",
            "params": {"code": COMMAND_CODE}
        })
        await self.hass.async_add_executor_job(time.sleep, 5)

    async def _refresh(self):
        await self.hass.services.async_call("homeassistant", "update_entity", {
            "entity_id": XBOX_PING_SENSOR
        })

    @property
    def is_on(self):
        state = self.hass.states.get(XBOX_PING_SENSOR)
        return state.state == STATE_ON if state else False
